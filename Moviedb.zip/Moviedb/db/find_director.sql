SELECT director.* FROM director WHERE first_name=$1;
