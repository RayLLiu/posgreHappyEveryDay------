SELECT * FROM topics;
