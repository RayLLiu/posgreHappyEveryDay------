SET SEARCH_PATH='moviedb';
SELECT * FROM users;
