Select a.*
From actor a
where a.first_name=$1;
