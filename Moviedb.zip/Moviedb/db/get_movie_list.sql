SET SEARCH_PATH='moviedb';
SELECT * FROM movie;
