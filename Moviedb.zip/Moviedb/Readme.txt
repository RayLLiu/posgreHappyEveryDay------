1Navigate to this folder,
2. $ npm install
3. $ DEBUG=myapp:* npm start

go to the browser, the url is "localhost:3000"

All the best Ray.
